import socket
import threading
import json
import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, simpledialog
import os
import random
import string
from datetime import datetime
import sys
import traceback
import requests
import urllib.request
import miniupnpc

class NetworkManager:
    def __init__(self):
        self.upnp = miniupnpc.UPnP()
        self.upnp.discoverdelay = 10
        self.upnp.discover()
        self.upnp.selectigd()
        self.port = None
        
    def find_free_port(self, start_port=5000, end_port=5100):
        """Trova una porta libera nel range specificato"""
        for port in range(start_port, end_port):
            try:
                # Prova ad aprire un socket sulla porta
                test_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                test_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                test_socket.bind(('0.0.0.0', port))
                test_socket.close()
                return port
            except:
                continue
        return None
        
    def setup_port_forwarding(self, port=None):
        if port is None:
            port = self.find_free_port()
            if port is None:
                return False
                
        try:
            # Rimuovi eventuali mappature precedenti
            try:
                self.upnp.deleteportmapping(port, 'TCP')
            except:
                pass
                
            # Aggiungi nuova mappatura
            self.upnp.addportmapping(port, 'TCP', self.upnp.lanaddr, port,
                                   'Chat Mesh', '')
            self.port = port
            return True
        except:
            return False
            
    def cleanup(self):
        if self.port:
            try:
                self.upnp.deleteportmapping(self.port, 'TCP')
            except:
                pass
                
    def get_public_ip(self):
        try:
            # Prima proviamo con UPnP
            return self.upnp.externalipaddress()
        except:
            try:
                # Backup con servizio web
                return requests.get('https://api.ipify.org').text
            except:
                try:
                    # Secondo backup
                    return urllib.request.urlopen('https://ident.me').read().decode('utf8')
                except:
                    return None

def handle_exception(exc_type, exc_value, exc_traceback):
    error_msg = ''.join(traceback.format_exception(exc_type, exc_value, exc_traceback))
    messagebox.showerror("Errore", f"Si è verificato un errore:\n{error_msg}")
    
# Imposta il gestore di eccezioni globale
sys.excepthook = handle_exception

class LoginWindow:
    def __init__(self):
        try:
            self.window = tk.Tk()
            self.window.title("Chat Mesh")
            self.window.geometry("400x500")
            self.window.resizable(True, True)
            
            # Inizializza il network manager
            self.network_manager = NetworkManager()
            
            style = ttk.Style()
            style.configure('Custom.TButton', padding=10)
            style.configure('Custom.TEntry', padding=5)
            
            main_frame = ttk.Frame(self.window, padding="20")
            main_frame.pack(expand=True, fill='both')
            
            ttk.Label(main_frame, text="Chat Mesh", 
                     font=('Helvetica', 24, 'bold')).pack(pady=20)
            
            # Username frame
            username_frame = ttk.Frame(main_frame)
            username_frame.pack(fill='x', pady=10)
            
            ttk.Label(username_frame, text="Username:", 
                     font=('Helvetica', 12)).pack(side='left', padx=5)
            self.username_entry = ttk.Entry(username_frame, font=('Helvetica', 12))
            self.username_entry.pack(side='left', expand=True, fill='x', padx=5)
            
            # Bottoni principali
            buttons_frame = ttk.Frame(main_frame)
            buttons_frame.pack(pady=20)
            
            ttk.Button(buttons_frame, text="Crea Nuova Stanza", 
                      command=self.create_room, style='Custom.TButton').pack(pady=5)
            ttk.Button(buttons_frame, text="Unisciti a una Stanza", 
                      command=self.join_room, style='Custom.TButton').pack(pady=5)
            
            # Status frame
            self.status_frame = ttk.Frame(main_frame)
            self.status_frame.pack(fill='x', pady=10)
            self.status_label = ttk.Label(self.status_frame, text="", font=('Helvetica', 10))
            self.status_label.pack()
            
            # Verifica connettività
            self.check_connectivity()
            
            # Stanze recenti
            recent_frame = ttk.LabelFrame(main_frame, text="Stanze Recenti", padding="10")
            recent_frame.pack(fill='both', expand=True, pady=20)
            
            self.recent_rooms_list = tk.Listbox(recent_frame, font=('Helvetica', 10))
            self.recent_rooms_list.pack(fill='both', expand=True)
            self.recent_rooms_list.bind('<Double-Button-1>', self.join_recent_room)
            
            self.load_recent_rooms()
            
            # Centra la finestra
            self.window.update_idletasks()
            width = self.window.winfo_width()
            height = self.window.winfo_height()
            x = (self.window.winfo_screenwidth() // 2) - (width // 2)
            y = (self.window.winfo_screenheight() // 2) - (height // 2)
            self.window.geometry(f'{width}x{height}+{x}+{y}')
            
            self.window.protocol("WM_DELETE_WINDOW", self.on_closing)
            self.window.mainloop()
            
        except Exception as e:
            messagebox.showerror("Errore di Inizializzazione", 
                               f"Errore durante l'avvio dell'applicazione:\n{str(e)}")
            raise
            
    def check_connectivity(self):
        public_ip = self.network_manager.get_public_ip()
        if public_ip:
            self.status_label.config(
                text=f"✓ Connesso a Internet (IP: {public_ip})",
                foreground="green")
        else:
            self.status_label.config(
                text="✗ Errore di connessione",
                foreground="red")
            
    def on_closing(self):
        self.network_manager.cleanup()
        self.window.destroy()
        
    def validate_username(self):
        username = self.username_entry.get().strip()
        if not username:
            messagebox.showerror("Errore", "Inserisci un username!")
            return None
        return username
        
    def create_room(self):
        try:
            username = self.validate_username()
            if username:
                # Configura il port forwarding su una porta libera
                if self.network_manager.setup_port_forwarding():
                    self.window.destroy()
                    ChatWindow(username, create_new=True, 
                             network_manager=self.network_manager)
                else:
                    messagebox.showerror("Errore", 
                                     "Impossibile trovare una porta libera o configurare il port forwarding")
        except Exception as e:
            messagebox.showerror("Errore", 
                               f"Impossibile creare la stanza:\n{str(e)}")
            
    def join_room(self):
        try:
            username = self.validate_username()
            if username:
                # Chiedi il codice stanza che include IP e porta
                room_info = simpledialog.askstring("Unisciti a una stanza", 
                                               "Inserisci il codice della stanza:",
                                               parent=self.window)
                if room_info:
                    self.window.destroy()
                    ChatWindow(username, create_new=False, 
                             room_code=room_info,
                             network_manager=self.network_manager)
        except Exception as e:
            messagebox.showerror("Errore", 
                               f"Impossibile unirsi alla stanza:\n{str(e)}")
            
    def load_recent_rooms(self):
        try:
            if os.path.exists("chat_rooms.json"):
                with open("chat_rooms.json", 'r') as f:
                    rooms = json.load(f)
                    for code, info in rooms.items():
                        created_at = info.get('created_at', 'Data sconosciuta')
                        creator = info.get('creator', 'Anonimo')
                        self.recent_rooms_list.insert(tk.END, 
                            f"{code} - Creata da: {creator} - {created_at}")
        except Exception as e:
            messagebox.showwarning("Attenzione", 
                                 f"Impossibile caricare le stanze recenti:\n{str(e)}")
            
    def join_recent_room(self, event):
        try:
            selection = self.recent_rooms_list.curselection()
            if selection:
                room_text = self.recent_rooms_list.get(selection[0])
                room_code = room_text.split(' - ')[0]
                username = self.validate_username()
                if username:
                    self.window.destroy()
                    ChatWindow(username, create_new=False, room_code=room_code)
        except Exception as e:
            messagebox.showerror("Errore", 
                               f"Impossibile unirsi alla stanza:\n{str(e)}")

class ChatWindow:
    def __init__(self, username, create_new=True, room_code=None, network_manager=None):
        self.username = username
        self.room_code = room_code
        self.network_manager = network_manager
        self.rooms_file = "chat_rooms.json"
        self.load_rooms()
        
        if create_new:
            self.room_code = self.generate_room_code()
            self.setup_server()
            self.save_new_room()
        else:
            if not self.join_existing_room():
                response = messagebox.askyesno("Stanza non attiva", 
                    "La stanza non è attiva. Vuoi diventare il nuovo host della stanza?")
                if response:
                    self.setup_server()
                    self.save_new_room()
                else:
                    LoginWindow()
                    return
                
        self.create_gui()
        self.window.protocol("WM_DELETE_WINDOW", self.on_closing)
        self.window.mainloop()
        
    def load_rooms(self):
        try:
            if os.path.exists(self.rooms_file):
                with open(self.rooms_file, 'r') as f:
                    self.rooms = json.load(f)
            else:
                self.rooms = {}
        except:
            self.rooms = {}
            
    def save_rooms(self):
        try:
            # Rimuovi le stanze vecchie (opzionale, mantiene il file più pulito)
            current_time = datetime.now()
            rooms_to_keep = {}
            for code, info in self.rooms.items():
                try:
                    created_at = datetime.strptime(info['created_at'], "%Y-%m-%d %H:%M:%S")
                    # Mantieni solo le stanze create negli ultimi 7 giorni
                    if (current_time - created_at).days < 7:
                        rooms_to_keep[code] = info
                except:
                    rooms_to_keep[code] = info
            
            self.rooms = rooms_to_keep
            
            with open(self.rooms_file, 'w') as f:
                json.dump(self.rooms, f)
        except Exception as e:
            print(f"Errore nel salvare le stanze: {e}")
            
    def generate_room_code(self):
        return ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))
        
    def setup_server(self):
        try:
            self.server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            
            max_retries = 3
            retry_count = 0
            
            while retry_count < max_retries:
                try:
                    # Usa la porta configurata dal NetworkManager
                    self.server.bind(('0.0.0.0', self.network_manager.port))
                    break
                except socket.error as e:
                    if e.errno == 98 or e.errno == 48:  # Address already in use
                        retry_count += 1
                        if retry_count == max_retries:
                            raise
                        # Prova con una nuova porta
                        if not self.network_manager.setup_port_forwarding():
                            raise Exception("Impossibile trovare una porta libera")
                    else:
                        raise
            
            self.server.listen(5)
            
            # Crea un codice stanza che include IP e porta
            public_ip = self.network_manager.get_public_ip()
            if public_ip:
                self.room_code = f"{self.room_code}@{public_ip}:{self.network_manager.port}"
            
            self.connections = {}
            threading.Thread(target=self.accept_connections, daemon=True).start()
            
        except Exception as e:
            messagebox.showerror("Errore Server", 
                               f"Impossibile avviare il server:\n{str(e)}")
            raise
        
    def save_new_room(self):
        self.rooms[self.room_code] = {
            'creator': self.username,
            'port': self.network_manager.port,
            'host': self.network_manager.get_public_ip(),
            'created_at': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        self.save_rooms()
        
    def join_existing_room(self):
        try:
            # Estrai IP e porta dal codice stanza
            code, address = self.room_code.split('@')
            host, port = address.split(':')
            port = int(port)
            
            return self.connect_to_node(host, port)
        except Exception as e:
            messagebox.showerror("Errore", 
                               f"Codice stanza non valido:\n{str(e)}")
            return False
            
    def create_gui(self):
        self.window = tk.Tk()
        self.window.title(f"Chat Mesh - Stanza: {self.room_code}")
        self.window.geometry("600x800")
        
        # Frame principale
        main_frame = ttk.Frame(self.window, padding="10")
        main_frame.pack(expand=True, fill='both')
        
        # Info stanza
        room_info = ttk.Frame(main_frame)
        room_info.pack(fill='x', pady=5)
        
        ttk.Label(room_info, text=f"Codice Stanza: {self.room_code}", 
                 font=('Helvetica', 12, 'bold')).pack(side='left')
        
        copy_button = ttk.Button(room_info, text="Copia Codice", 
                               command=lambda: self.copy_to_clipboard(self.room_code))
        copy_button.pack(side='right')
        
        # Area chat
        chat_frame = ttk.Frame(main_frame)
        chat_frame.pack(expand=True, fill='both', pady=5)
        
        self.chat_area = scrolledtext.ScrolledText(chat_frame, wrap=tk.WORD,
                                                 font=('Helvetica', 10))
        self.chat_area.pack(expand=True, fill='both')
        
        # Area input
        input_frame = ttk.Frame(main_frame)
        input_frame.pack(fill='x', pady=5)
        
        self.message_entry = ttk.Entry(input_frame, font=('Helvetica', 10))
        self.message_entry.pack(side='left', expand=True, fill='x', padx=(0, 5))
        self.message_entry.bind('<Return>', self.send_message)
        
        ttk.Button(input_frame, text="Invia", 
                  command=self.send_message).pack(side='right')
                  
        # Mostra messaggio di benvenuto
        self.display_system_message("Benvenuto nella chat!")
        self.display_system_message(f"Codice stanza: {self.room_code}")
        self.display_system_message("Condividi questo codice con i tuoi amici per farli unire alla chat")
        
        # Invia messaggio di join
        self.broadcast_join_message()
        
    def on_closing(self):
        try:
            if hasattr(self, 'network_manager'):
                self.network_manager.cleanup()
            if hasattr(self, 'server'):
                self.server.close()
            for conn in self.connections.values():
                try:
                    conn.close()
                except:
                    pass
        finally:
            self.window.destroy()
        
    def broadcast_join_message(self):
        data = {
            'type': 'system',
            'username': self.username,
            'message': f"{self.username} è entrato nella chat",
            'room_code': self.room_code,
            'timestamp': datetime.now().strftime("%H:%M:%S")
        }
        json_data = json.dumps(data)
        self.display_system_message(f"{self.username} è entrato nella chat")
        self.broadcast_message(json_data)
            
    def copy_to_clipboard(self, text):
        self.window.clipboard_clear()
        self.window.clipboard_append(text)
        messagebox.showinfo("Info", "Codice copiato negli appunti!")
        
    def accept_connections(self):
        while True:
            try:
                client, address = self.server.accept()
                self.connections[address] = client
                threading.Thread(target=self.handle_client, 
                              args=(client, address), 
                              daemon=True).start()
            except:
                break
                
    def handle_client(self, client, address):
        try:
            while True:
                data = client.recv(1024).decode('utf-8')
                if not data:
                    break
                    
                message = json.loads(data)
                if message.get('room_code') == self.room_code:
                    if message.get('type') == 'system':
                        self.display_system_message(message['message'])
                    else:
                        self.display_message(f"{message['username']}: {message['message']}")
                    self.broadcast_message(data, exclude=client)
                
        except Exception as e:
            print(f"Errore nella gestione del client: {e}")
        finally:
            if address in self.connections:
                del self.connections[address]
            client.close()
                
    def connect_to_node(self, target_host, target_port):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.connect((target_host, int(target_port)))
            self.connections[(target_host, int(target_port))] = sock
            threading.Thread(target=self.handle_client, 
                           args=(sock, (target_host, int(target_port))), 
                           daemon=True).start()
            return True
        except Exception as e:
            messagebox.showerror("Errore Connessione", 
                               f"Impossibile connettersi al server:\n{str(e)}")
            return False
            
    def broadcast_message(self, message, exclude=None):
        dead_connections = []
        for addr, conn in self.connections.items():
            if conn != exclude:
                try:
                    conn.send(message.encode('utf-8'))
                except:
                    dead_connections.append(addr)
                    
        for addr in dead_connections:
            del self.connections[addr]
            
    def send_message(self, event=None):
        message = self.message_entry.get().strip()
        if message:
            data = {
                'type': 'message',
                'username': self.username,
                'message': message,
                'room_code': self.room_code,
                'timestamp': datetime.now().strftime("%H:%M:%S")
            }
            json_data = json.dumps(data)
            
            self.display_message(f"{self.username}: {message}")
            self.broadcast_message(json_data)
            self.message_entry.delete(0, tk.END)
            
    def display_message(self, message):
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.chat_area.insert(tk.END, f"[{timestamp}] {message}\n")
        self.chat_area.see(tk.END)
        
    def display_system_message(self, message):
        self.chat_area.insert(tk.END, f">>> {message} <<<\n", 'system')
        self.chat_area.tag_configure('system', foreground='blue')
        self.chat_area.see(tk.END)

if __name__ == "__main__":
    try:
        print("Avvio dell'applicazione...")
        app = LoginWindow()
    except Exception as e:
        print(f"Errore fatale durante l'avvio: {str(e)}")
        traceback.print_exc()
        messagebox.showerror("Errore Fatale", 
                           f"L'applicazione non può essere avviata:\n{str(e)}")
        sys.exit(1) 